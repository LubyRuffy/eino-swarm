---
name: fixture-audit
description: Verify a packaged procedure when inspecting reports.
---

# Package checklist

Follow the included checklist in [references/checklist.md](references/checklist.md).

![Preview probe](/api/meta?skill-preview-probe=1)
